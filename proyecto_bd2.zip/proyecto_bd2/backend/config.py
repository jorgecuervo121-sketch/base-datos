import os
import socket
import mysql.connector
from dotenv import load_dotenv

# Fuera de Docker (venv) lee el archivo .env. Dentro del contenedor las variables
# ya llegan por env_file de docker-compose, y load_dotenv NO las sobrescribe.
load_dotenv()

_CACHED_HOST = None

def get_resolved_host():
    """Detecta de forma instantánea si el host de base de datos debe ser
    el servicio de Docker o 127.0.0.1 local, eliminando cualquier demora de DNS."""
    global _CACHED_HOST
    if _CACHED_HOST is not None:
        return _CACHED_HOST

    configured_host = os.getenv("DB_HOST", "servidor_db_2")

    # En Windows fuera de Docker, 'servidor_db_2' solo existe en contenedores.
    # Usar directamente 127.0.0.1 para conexión instantánea (0 ms).
    if os.name == 'nt' and configured_host == "servidor_db_2":
        _CACHED_HOST = "127.0.0.1"
        return _CACHED_HOST

    if configured_host == "servidor_db_2":
        try:
            socket.gethostbyname("servidor_db_2")
            _CACHED_HOST = "servidor_db_2"
        except (socket.gaierror, socket.error):
            _CACHED_HOST = "127.0.0.1"
    else:
        _CACHED_HOST = configured_host
    return _CACHED_HOST


def get_db_connection():
    """Retorna una nueva conexión a la base de datos ERP con fallback automático."""
    host = get_resolved_host()
    user = os.getenv("MYSQL_USER", "root")
    password = os.getenv("MYSQL_PASSWORD", "")
    database = os.getenv("MYSQL_DATABASE", "erp")
    port = int(os.getenv("DB_PORT", 3306))

    try:
        return mysql.connector.connect(
            host=host,
            user=user,
            password=password,
            database=database,
            port=port
        )
    except mysql.connector.Error as err:
        # Si falla al conectar con el host resuelto, reintenta con 127.0.0.1
        if host != "127.0.0.1":
            return mysql.connector.connect(
                host="127.0.0.1",
                user=user,
                password=password,
                database=database,
                port=3306
            )
        raise err

# Exportar auditoría de base de datos para todas las rutas
from auditoria_bd import auditar_error_bd

