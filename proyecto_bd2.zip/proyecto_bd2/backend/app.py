from flask import Flask, jsonify, render_template, request
from routes.productos import productos_bp
from routes.terceros import terceros_bp
from routes.ventas import ventas_bp
from routes.pedidos import pedidos_bp
from routes.usuarios import usuarios_bp

app = Flask(__name__)

# Habilitar CORS para permitir peticiones desde cualquier origen (ej. Live Server o navegador)
@app.after_request
def add_cors_headers(response):
    response.headers['Access-Control-Allow-Origin'] = '*'
    response.headers['Access-Control-Allow-Headers'] = 'Content-Type,Authorization'
    response.headers['Access-Control-Allow-Methods'] = 'GET,PUT,POST,PATCH,DELETE,OPTIONS'
    return response

# Responder a preflight OPTIONS para cualquier endpoint
@app.route('/<path:dummy>', methods=['OPTIONS'])
@app.route('/', methods=['OPTIONS'])
def options_handler(dummy=None):
    return ('', 204)

# register_blueprint conecta los grupos de rutas con la aplicación principal.
# url_prefix define la raíz de las rutas de cada módulo.
app.register_blueprint(productos_bp)
app.register_blueprint(terceros_bp)
app.register_blueprint(ventas_bp)
app.register_blueprint(pedidos_bp)
app.register_blueprint(usuarios_bp)

@app.route('/', methods=['GET'])
def inicio():
    # Renderiza la interfaz web del dashboard
    return render_template('index.html')


if __name__ == '__main__':
    # host='0.0.0.0' es obligatorio en Docker: con 127.0.0.1 Flask solo
    # escucharía dentro del contenedor y el puerto publicado no le llegaría
    app.run(host='0.0.0.0', port=5000, debug=True)
