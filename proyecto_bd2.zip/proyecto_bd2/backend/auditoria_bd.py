"""
Módulo de Auditoría de Errores de Base de Datos MySQL
======================================================
Cumplimiento de estándares de desarrollo
-Auditoría de Errores: Captura y evaluación explícita de mysql.connector.Error.
   Prohibido el uso de capturas genéricas (except Exception) para reglas de negocio.
-Mensajes Concordantes: Los mensajes de error y validación corresponden exactamente
   a la causa y condición del fallo.
"""

from datetime import datetime
import mysql.connector
from mysql.connector import Error
from flask import jsonify


def auditar_error_bd(err: mysql.connector.Error, operacion: str = "Operación de Base de Datos"):
    """
    Inspecciona y audita detalladamente una excepción de mysql.connector.Error.
    
    Extrae:
    - err.errno: Código numérico del error de MySQL.
    - err.sqlstate: Código SQLState estándar ANSI/ISO.
    - err.msg: Mensaje generado por el motor o por un TRIGGER (SIGNAL 45000).
    
    Evalúa las reglas de negocio de la base de datos y retorna una tupla:
    (Response JSON, HTTP status code).
    """
    codigo = getattr(err, 'errno', None)
    sqlstate = getattr(err, 'sqlstate', None)
    mensaje_motor = getattr(err, 'msg', str(err))
    ahora = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

    # Registro de auditoría estructurado en consola del servidor
    print(f"[AUDITORIA_BD {ahora}] OPERACIÓN: '{operacion}' | CÓDIGO (errno): {codigo} | SQLSTATE: '{sqlstate}'")
    print(f"                      MENSAJE MOTOR: {mensaje_motor}")

    # 1. EVALUACIÓN DE REGLAS DE NEGOCIO: TRIGGERS (SIGNAL SQLSTATE '45000' / errno 1644)
    if codigo == 1644 or sqlstate == '45000':
        msg_limpio = mensaje_motor
        if "MESSAGE_TEXT = '" in msg_limpio:
            msg_limpio = msg_limpio.split("MESSAGE_TEXT = '")[1].split("'")[0]
        else:
            for prefijo in ["Seguridad: ", "Operación denegada: ", "Acción denegada: ", "Error: ", "Validación: "]:
                if msg_limpio.startswith(prefijo):
                    msg_limpio = msg_limpio[len(prefijo):]
                    break

        return jsonify({
            "error": msg_limpio.strip(),
            "codigo_bd": codigo,
            "sqlstate": sqlstate,
            "tipo_auditoria": "REGLA_NEGOCIO_TRIGGER"
        }), 400

    # 2. INTEGRIDAD REFERENCIAL / CLAVES FORÁNEAS (errno 1451, 1452)
    if codigo == 1451:
        return jsonify({
            "error": "Integridad referencial: No es posible eliminar o alterar el registro porque tiene datos vinculados (pedidos, ventas o detalles asociados).",
            "codigo_bd": codigo,
            "sqlstate": sqlstate,
            "tipo_auditoria": "RESTRICCION_CLAVE_FORANEA_DELETE"
        }), 400

    if codigo == 1452:
        return jsonify({
            "error": "Integridad referencial: El registro referenciado (cliente, usuario o producto) no existe en la base de datos.",
            "codigo_bd": codigo,
            "sqlstate": sqlstate,
            "tipo_auditoria": "RESTRICCION_CLAVE_FORANEA_INSERT"
        }), 400

    # 3. REGISTROS DUPLICADOS / CLAVE ÚNICA (errno 1062)
    if codigo == 1062:
        return jsonify({
            "error": "Validación de unicidad: Ya existe un registro con el mismo identificador, nombre o correo en la base de datos.",
            "codigo_bd": codigo,
            "sqlstate": sqlstate,
            "tipo_auditoria": "CLAVE_DUPLICADA"
        }), 400

    # 4. RESTRICCIÓN CHECK (errno 3819)
    if codigo == 3819:
        return jsonify({
            "error": "Restricción de validación: Los datos ingresados violan una regla CHECK definida en la base de datos.",
            "codigo_bd": codigo,
            "sqlstate": sqlstate,
            "tipo_auditoria": "RESTRICCION_CHECK"
        }), 400

    # 5. CAMPOS NOT NULL OBLIGATORIOS (errno 1048)
    if codigo == 1048:
        return jsonify({
            "error": "Campo obligatorio: Uno o más campos requeridos no pueden quedar vacíos o nulos.",
            "codigo_bd": codigo,
            "sqlstate": sqlstate,
            "tipo_auditoria": "CAMPO_REQUERIDO_NULL"
        }), 400

    # 6. VALORES NUMÉRICOS O CADENAS FUERA DE RANGO (errno 1264, 1406)
    if codigo in (1264, 1406):
        return jsonify({
            "error": "Rango excedido: Uno de los valores numéricos o cadenas de texto supera la capacidad permitida por la base de datos.",
            "codigo_bd": codigo,
            "sqlstate": sqlstate,
            "tipo_auditoria": "VALOR_FUERA_DE_RANGO"
        }), 400

    # 7. ERRORES DE CONEXIÓN O DISPONIBILIDAD DEL SERVIDOR MYSQL (errno 2002, 2003, 2006, 2013)
    if codigo in (2002, 2003, 2006, 2013):
        return jsonify({
            "error": "Fallo de conexión: No se pudo establecer comunicación con el servidor MySQL en el puerto configurado.",
            "codigo_bd": codigo,
            "sqlstate": sqlstate,
            "tipo_auditoria": "FALLO_CONEXION_MYSQL"
        }), 503

    # 8. CUALQUIER OTRO ERROR INTERNO DE BASE DE DATOS
    return jsonify({
        "error": f"Error de base de datos ({codigo}): {mensaje_motor}",
        "codigo_bd": codigo,
        "sqlstate": sqlstate,
        "tipo_auditoria": "ERROR_MOTOR_MYSQL"
    }), 500
