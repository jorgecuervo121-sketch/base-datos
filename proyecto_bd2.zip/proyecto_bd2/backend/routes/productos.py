import mysql.connector
from flask import Blueprint, jsonify, request
from config import get_db_connection, auditar_error_bd

productos_bp = Blueprint('productos', __name__, url_prefix='/api/productos')

_orig_register_productos = productos_bp.register
def _safe_register_productos(app, options):
    if options.get("url_prefix") == productos_bp.url_prefix:
        options = dict(options)
        options.pop("url_prefix", None)
    return _orig_register_productos(app, options)
productos_bp.register = _safe_register_productos


@productos_bp.route('/', methods=['GET'])
def obtener_productos():
    """
    Endpoint para consultar la lista de productos activos.
    SQL crudo con cursor en modo diccionario (dictionary=True).
    Auditoría estricta de mysql.connector.Error.
    """
    conn = None
    cursor = None
    try:
        conn = get_db_connection()
        cursor = conn.cursor(dictionary=True)
        cursor.execute("""
            SELECT id_producto, nombre, cantidad_stock, nivel_minimo, precioCompra, precioVenta, tarifa_iva, estado 
            FROM productos 
            WHERE estado = 1 
            ORDER BY id_producto DESC;
        """)
        productos = cursor.fetchall()
        return jsonify(productos), 200
    except mysql.connector.Error as err:
        return auditar_error_bd(err, "obtener_productos")
    finally:
        if cursor:
            cursor.close()
        if conn:
            conn.close()


@productos_bp.route('/', methods=['POST'])
def crear_producto():
    """
    Endpoint para registrar un nuevo producto en el inventario.
    """
    datos = request.json
    if not datos or 'nombre' not in datos or 'cantidad_stock' not in datos:
        return jsonify({"error": "Validación: Los campos 'nombre' y 'cantidad_stock' son obligatorios para crear el producto."}), 400

    nombre = str(datos['nombre']).strip()
    if not nombre:
        return jsonify({"error": "Validación: El nombre del producto no puede estar vacío."}), 400

    try:
        cant_stock = int(datos.get('cantidad_stock', 0))
        nivel_min = int(datos.get('nivel_minimo', 5))
        precio_compra = float(datos.get('precioCompra', 0.0))
        precio_venta = float(datos.get('precioVenta', 0.0))
        tarifa_iva = float(datos.get('tarifa_iva', 0.19))
    except (ValueError, TypeError):
        return jsonify({"error": "Validación: Las existencias, niveles y precios deben ser valores numéricos válidos."}), 400

    if cant_stock < 0:
        return jsonify({"error": "Validación: La cantidad inicial de stock no puede ser un valor negativo."}), 400

    if nivel_min < 0:
        return jsonify({"error": "Validación: El nivel mínimo de inventario no puede ser negativo."}), 400

    if precio_compra < 0 or precio_venta < 0:
        return jsonify({"error": "Validación: Ni el precio de compra ni el de venta pueden ser negativos."}), 400

    conn = None
    cursor = None
    try:
        conn = get_db_connection()
        cursor = conn.cursor(dictionary=True)

        sql = """
            INSERT INTO productos (nombre, cantidad_stock, nivel_minimo, precioCompra, precioVenta, tarifa_iva, estado)
            VALUES (%s, %s, %s, %s, %s, %s, %s)
        """
        valores = (
            nombre,
            cant_stock,
            nivel_min,
            precio_compra,
            precio_venta,
            tarifa_iva,
            int(datos.get('estado', 1))
        )

        cursor.execute(sql, valores)
        conn.commit()

        id_nuevo = cursor.lastrowid
        return jsonify({
            "mensaje": f"Producto '{nombre}' registrado exitosamente con ID #{id_nuevo}.",
            "id_producto": id_nuevo
        }), 201

    except mysql.connector.Error as err:
        if conn:
            conn.rollback()
        return auditar_error_bd(err, "crear_producto")

    finally:
        if cursor:
            cursor.close()
        if conn:
            conn.close()


@productos_bp.route('/<int:id_producto>', methods=['PUT'])
def actualizar_producto(id_producto):
    """
    Endpoint para actualizar los datos administrativos de un producto.
    """
    datos = request.json
    if not datos:
        return jsonify({"error": "Validación: No se enviaron datos para actualizar el producto."}), 400

    if 'nombre' not in datos or 'cantidad_stock' not in datos or 'nivel_minimo' not in datos:
        return jsonify({"error": "Validación: Los campos 'nombre', 'cantidad_stock' y 'nivel_minimo' son obligatorios."}), 400

    nombre = str(datos['nombre']).strip()
    if not nombre:
        return jsonify({"error": "Validación: El nombre del producto no puede estar vacío."}), 400

    try:
        cant_stock = int(datos.get('cantidad_stock', 0))
        nivel_min = int(datos.get('nivel_minimo', 5))
        precio_compra = float(datos.get('precioCompra', 0.0))
        precio_venta = float(datos.get('precioVenta', 0.0))
        tarifa_iva = float(datos.get('tarifa_iva', 0.19))
    except (ValueError, TypeError):
        return jsonify({"error": "Validación: Las existencias y precios deben ser valores numéricos válidos."}), 400

    if cant_stock < 0:
        return jsonify({"error": "Validación: La cantidad en stock no puede ser un valor negativo."}), 400

    if nivel_min < 0:
        return jsonify({"error": "Validación: El nivel mínimo de inventario no puede ser negativo."}), 400

    if precio_compra < 0 or precio_venta < 0:
        return jsonify({"error": "Validación: Los precios no pueden ser negativos."}), 400

    conn = None
    cursor = None
    try:
        conn = get_db_connection()
        cursor = conn.cursor(dictionary=True)

        sql = """
            UPDATE productos
            SET nombre = %s,
                cantidad_stock = %s,
                nivel_minimo = %s,
                precioCompra = %s,
                precioVenta = %s,
                tarifa_iva = %s,
                estado = %s
            WHERE id_producto = %s
        """
        valores = (
            nombre,
            cant_stock,
            nivel_min,
            precio_compra,
            precio_venta,
            tarifa_iva,
            int(datos.get('estado', 1)),
            id_producto
        )

        cursor.execute(sql, valores)
        conn.commit()

        if cursor.rowcount == 0:
            return jsonify({"mensaje": f"Validación: No se detectaron cambios a aplicar o el producto #{id_producto} no existe."}), 404

        return jsonify({"mensaje": f"Producto #{id_producto} actualizado correctamente."}), 200

    except mysql.connector.Error as err:
        if conn:
            conn.rollback()
        return auditar_error_bd(err, "actualizar_producto")

    finally:
        if cursor:
            cursor.close()
        if conn:
            conn.close()


@productos_bp.route('/<int:id_producto>', methods=['PATCH'])
def actualizar_parcial_producto(id_producto):
    """
    Endpoint para actualización parcial de un producto.
    """
    datos = request.json
    if not datos:
        return jsonify({"error": "Validación: No se enviaron datos para actualizar."}), 400

    campos_permitidos = ['nombre', 'cantidad_stock', 'nivel_minimo', 'precioCompra', 'precioVenta', 'tarifa_iva', 'estado']
    campos_a_actualizar = []
    valores = []

    for campo in campos_permitidos:
        if campo in datos:
            campos_a_actualizar.append(f"{campo} = %s")
            valores.append(datos[campo])

    if not campos_a_actualizar:
        return jsonify({"error": "Validación: No se enviaron campos válidos para actualizar."}), 400

    valores.append(id_producto)
    sql = f"UPDATE productos SET {', '.join(campos_a_actualizar)} WHERE id_producto = %s"

    conn = None
    cursor = None
    try:
        conn = get_db_connection()
        cursor = conn.cursor(dictionary=True)
        cursor.execute(sql, tuple(valores))
        conn.commit()

        if cursor.rowcount == 0:
            return jsonify({"mensaje": f"Validación: No se realizaron cambios o el producto #{id_producto} no existe."}), 404

        return jsonify({"mensaje": f"Producto #{id_producto} actualizado parcialmente con éxito."}), 200

    except mysql.connector.Error as err:
        if conn:
            conn.rollback()
        return auditar_error_bd(err, "actualizar_parcial_producto")

    finally:
        if cursor:
            cursor.close()
        if conn:
            conn.close()


@productos_bp.route('/<int:id_producto>', methods=['DELETE'])
def eliminar_producto(id_producto):
    """
    Endpoint para borrado lógico (Soft Delete) de un producto.
    """
    conn = None
    cursor = None
    try:
        conn = get_db_connection()
        cursor = conn.cursor(dictionary=True)

        cursor.execute("SELECT id_producto, nombre, cantidad_stock FROM productos WHERE id_producto = %s", (id_producto,))
        prod = cursor.fetchone()
        if not prod:
            return jsonify({"error": f"Validación: El producto #{id_producto} no existe en el catálogo."}), 404

        if prod['cantidad_stock'] > 0:
            return jsonify({"error": f"Validación: No se puede inactivar el producto '{prod['nombre']}' porque aún cuenta con {prod['cantidad_stock']} unidades en existencias."}), 400

        cursor.execute("SELECT COUNT(*) AS cant FROM detalle_pedido WHERE id_producto = %s", (id_producto,))
        p = cursor.fetchone()
        if p and p['cant'] > 0:
            return jsonify({"error": f"Validación: No se puede inactivar el producto '{prod['nombre']}' porque se encuentra vinculado a pedidos u órdenes de compra."}), 400

        cursor.execute("SELECT COUNT(*) AS cant FROM detalleventa WHERE id_producto = %s", (id_producto,))
        v = cursor.fetchone()
        if v and v['cant'] > 0:
            return jsonify({"error": f"Validación: No se puede inactivar el producto '{prod['nombre']}' porque tiene ventas registradas en el sistema."}), 400

        cursor.execute("UPDATE productos SET estado = 0 WHERE id_producto = %s", (id_producto,))
        conn.commit()

        return jsonify({"mensaje": f"Producto '{prod['nombre']}' (#{id_producto}) inactivado correctamente."}), 200

    except mysql.connector.Error as err:
        if conn:
            conn.rollback()
        return auditar_error_bd(err, "eliminar_producto")

    finally:
        if cursor:
            cursor.close()
        if conn:
            conn.close()
