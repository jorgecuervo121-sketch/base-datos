import mysql.connector
from flask import Blueprint, jsonify, request
from config import get_db_connection, auditar_error_bd

ventas_bp = Blueprint('ventas', __name__, url_prefix='/api/ventas')

_orig_register_ventas = ventas_bp.register
def _safe_register_ventas(app, options):
    if options.get("url_prefix") == ventas_bp.url_prefix:
        options = dict(options)
        options.pop("url_prefix", None)
    return _orig_register_ventas(app, options)
ventas_bp.register = _safe_register_ventas

ESTADOS_VALIDOS_VENTA = {'Pendiente', 'Pagado', 'Anulado', 'Enviado', 'Por Pagar'}


@ventas_bp.route('/', methods=['GET'])
def obtener_ventas():
    """
    Consulta el listado general de ventas con cliente y vendedor asociados.
    SQL crudo con cursor en modo diccionario (dictionary=True).
    Auditoría estricta de mysql.connector.Error.
    """
    conn = None
    cursor = None
    try:
        conn = get_db_connection()
        cursor = conn.cursor(dictionary=True)
        sql = """
            SELECT 
                v.id_venta, 
                v.fecha_venta, 
                v.total_venta, 
                v.estado_venta, 
                v.id_usuario, 
                COALESCE(u.nombre, 'Usuario Desconocido') AS nombre_usuario,
                v.id_tercero, 
                COALESCE(t.nombre, 'Tercero Desconocido') AS nombre_tercero
            FROM ventas v
            LEFT JOIN terceros t ON v.id_tercero = t.id_tercero
            LEFT JOIN usuarios u ON v.id_usuario = u.id_usuario
            ORDER BY v.id_venta DESC;
        """
        cursor.execute(sql)
        ventas = cursor.fetchall()
        return jsonify(ventas), 200
    except mysql.connector.Error as err:
        return auditar_error_bd(err, "obtener_ventas")
    finally:
        if cursor:
            cursor.close()
        if conn:
            conn.close()


@ventas_bp.route('/', methods=['POST'])
def crear_venta():
    """
    Registra una nueva venta completa (Maestro-Detalle).
    Valida previamente existencias, costos y reglas de negocio, y audita con mysql.connector.Error.
    """
    datos = request.json
    if not datos:
        return jsonify({"error": "Validación: No se recibieron datos para facturar la venta."}), 400

    id_tercero = datos.get('id_tercero') or datos.get('tercero_id_tercero')
    id_usuario = datos.get('id_usuario') or datos.get('usuarios_id_usuario')
    estado_venta = datos.get('estado_venta', 'Pendiente')
    detalles = datos.get('detalles', [])

    if not id_tercero or not id_usuario:
        return jsonify({"error": "Validación: Debe seleccionar un cliente y un usuario vendedor responsable."}), 400

    if not isinstance(detalles, list) or len(detalles) == 0:
        return jsonify({"error": "Validación: La venta debe contener al menos un producto a facturar."}), 400

    if estado_venta not in ESTADOS_VALIDOS_VENTA:
        return jsonify({"error": f"Validación: El estado '{estado_venta}' no es válido para una venta."}), 400

    conn = None
    cursor = None
    try:
        conn = get_db_connection()
        cursor = conn.cursor(dictionary=True)

        # 1. Validaciones previas por cada producto a facturar
        for item in detalles:
            if 'id_producto' not in item or 'cantidad' not in item or 'precioUnitario' not in item:
                return jsonify({"error": "Validación: Estructura de producto incompleta en los detalles de la venta."}), 400

            try:
                id_prod = int(item['id_producto'])
                cant = int(item['cantidad'])
                precio = float(item['precioUnitario'])
            except (ValueError, TypeError):
                return jsonify({"error": "Validación: La cantidad y el precio deben ser valores numéricos válidos."}), 400

            if cant <= 0:
                return jsonify({"error": "Validación: La cantidad a facturar debe ser un número entero mayor a cero."}), 400

            if precio < 0:
                return jsonify({"error": "Validación: El precio unitario de venta no puede ser negativo."}), 400

            cursor.execute("SELECT id_producto, nombre, cantidad_stock, precioCompra, estado FROM productos WHERE id_producto = %s", (id_prod,))
            prod = cursor.fetchone()
            if not prod:
                return jsonify({"error": f"Validación: El producto con ID #{id_prod} no existe en el catálogo."}), 404

            if prod['estado'] == 0:
                return jsonify({"error": f"Validación: El producto '{prod['nombre']}' se encuentra inactivo y no puede facturarse."}), 400

            costo = float(prod['precioCompra'] or 0.0)
            if precio < costo:
                return jsonify({"error": f"Validación: El precio de venta (${precio:,.2f}) no puede ser menor al costo de compra (${costo:,.2f}) para '{prod['nombre']}'."}), 400

            stock_disp = int(prod['cantidad_stock'] or 0)
            if cant > stock_disp:
                return jsonify({"error": f"Stock insuficiente: La cantidad solicitada ({cant} un.) supera las existencias disponibles ({stock_disp} un.) para '{prod['nombre']}'."}), 400

        # 2. Insertar cabecera de la venta
        sql_venta = """
            INSERT INTO ventas (id_usuario, id_tercero, estado_venta)
            VALUES (%s, %s, %s)
        """
        cursor.execute(sql_venta, (id_usuario, id_tercero, estado_venta))
        id_venta_generado = cursor.lastrowid

        # 3. Insertar detalles
        sql_detalle = """
            INSERT INTO detalleventa (id_venta, id_producto, cantidad, precioUnitario, porcentaje_iva)
            VALUES (%s, %s, %s, %s, %s)
        """
        for item in detalles:
            cant = int(item['cantidad'])
            precio = float(item['precioUnitario'])
            iva = float(item.get('porcentaje_iva', 0.19))
            cursor.execute(sql_detalle, (id_venta_generado, int(item['id_producto']), cant, precio, iva))

        conn.commit()

        return jsonify({
            "mensaje": f"Venta #{id_venta_generado} facturada exitosamente.",
            "id_venta": id_venta_generado
        }), 201

    except mysql.connector.Error as err:
        if conn:
            conn.rollback()
        return auditar_error_bd(err, "crear_venta")

    finally:
        if cursor:
            cursor.close()
        if conn:
            conn.close()


@ventas_bp.route('/<int:id_venta>', methods=['GET'])
def obtener_venta_completa(id_venta):
    """
    Extrae la cabecera de la venta y sus productos asociados.
    """
    conn = None
    cursor = None
    try:
        conn = get_db_connection()
        cursor = conn.cursor(dictionary=True)

        sql_cabecera = """
            SELECT 
                v.id_venta, 
                v.fecha_venta, 
                v.total_venta, 
                v.estado_venta,
                v.id_usuario, 
                COALESCE(u.nombre, 'Usuario Desconocido') AS nombre_usuario,
                v.id_tercero, 
                COALESCE(t.nombre, 'Tercero Desconocido') AS nombre_tercero
            FROM ventas v
            LEFT JOIN terceros t ON v.id_tercero = t.id_tercero
            LEFT JOIN usuarios u ON v.id_usuario = u.id_usuario
            WHERE v.id_venta = %s
        """
        cursor.execute(sql_cabecera, (id_venta,))
        venta = cursor.fetchone()

        if not venta:
            return jsonify({"error": f"Validación: La venta #{id_venta} no fue encontrada en el sistema."}), 404

        sql_detalles = """
            SELECT 
                dv.id_detalle_venta, 
                dv.id_producto, 
                p.nombre AS nombre_producto, 
                dv.cantidad, 
                dv.precioUnitario, 
                dv.subtotal, 
                dv.porcentaje_iva, 
                dv.total_venta
            FROM detalleventa dv
            INNER JOIN productos p ON dv.id_producto = p.id_producto
            WHERE dv.id_venta = %s
        """
        cursor.execute(sql_detalles, (id_venta,))
        venta['detalles'] = cursor.fetchall()

        return jsonify(venta), 200

    except mysql.connector.Error as err:
        return auditar_error_bd(err, "obtener_venta_completa")

    finally:
        if cursor:
            cursor.close()
        if conn:
            conn.close()


@ventas_bp.route('/<int:id_venta>', methods=['PUT'])
def actualizar_venta(id_venta):
    """
    Modifica una venta completa (Cabecera y Maestro-Detalle).
    """
    datos = request.json
    if not datos:
        return jsonify({"error": "Validación: No se recibieron datos para actualizar la venta."}), 400

    if 'detalles' not in datos and ('estado_venta' in datos or 'estado' in datos):
        return actualizar_estado_venta(id_venta)

    detalles = datos.get('detalles')
    if not isinstance(detalles, list) or len(detalles) == 0:
        return jsonify({"error": "Validación: La venta debe contener al menos un producto en el detalle."}), 400

    id_tercero = datos.get('id_tercero') or datos.get('tercero_id_tercero')
    id_usuario = datos.get('id_usuario') or datos.get('usuarios_id_usuario')
    nuevo_estado = datos.get('estado_venta')

    conn = None
    cursor = None
    try:
        conn = get_db_connection()
        cursor = conn.cursor(dictionary=True)

        cursor.execute("SELECT estado_venta FROM ventas WHERE id_venta = %s", (id_venta,))
        venta_actual = cursor.fetchone()
        if not venta_actual:
            return jsonify({"error": f"Validación: La venta #{id_venta} no existe en el sistema."}), 404

        if venta_actual['estado_venta'] in ('Pagado', 'Enviado', 'Anulado'):
            return jsonify({"error": f"Seguridad: No se puede modificar una venta que ya ha sido marcada como '{venta_actual['estado_venta']}'."}), 400

        # Obtener detalles previos
        cursor.execute("SELECT id_detalle_venta, id_producto, cantidad, precioUnitario, porcentaje_iva FROM detalleventa WHERE id_venta = %s", (id_venta,))
        detalles_previos = cursor.fetchall()
        mapa_previos = {d['id_producto']: d for d in detalles_previos}

        # Validaciones de cada producto
        for item in detalles:
            if 'id_producto' not in item or 'cantidad' not in item or 'precioUnitario' not in item:
                return jsonify({"error": "Validación: Estructura de producto incompleta en los detalles de la venta."}), 400

            try:
                id_prod = int(item['id_producto'])
                cant = int(item['cantidad'])
                precio = float(item['precioUnitario'])
            except (ValueError, TypeError):
                return jsonify({"error": "Validación: La cantidad y el precio deben ser valores numéricos válidos."}), 400

            if cant <= 0:
                return jsonify({"error": "Validación: La cantidad de cada producto debe ser mayor a cero."}), 400

            if precio < 0:
                return jsonify({"error": "Validación: El precio unitario de venta no puede ser negativo."}), 400

            cursor.execute("SELECT nombre, estado, cantidad_stock, precioCompra FROM productos WHERE id_producto = %s", (id_prod,))
            prod = cursor.fetchone()
            if not prod:
                return jsonify({"error": f"Validación: El producto con ID #{id_prod} no existe en el catálogo."}), 404

            if prod['estado'] == 0:
                return jsonify({"error": f"Validación: El producto '{prod['nombre']}' se encuentra inactivo y no puede facturarse."}), 400

            costo = float(prod['precioCompra'] or 0.0)
            if precio < costo:
                return jsonify({"error": f"Validación: El precio de venta (${precio:,.2f}) no puede ser menor al costo (${costo:,.2f}) para '{prod['nombre']}'."}), 400

            cant_ant = int(mapa_previos[id_prod]['cantidad']) if id_prod in mapa_previos else 0
            dif_requerida = cant - cant_ant
            stock_disp = int(prod['cantidad_stock'] or 0)
            if dif_requerida > stock_disp:
                return jsonify({"error": f"Stock insuficiente: La cantidad adicional requerida ({dif_requerida} un.) supera el stock disponible ({stock_disp} un.) para '{prod['nombre']}'."}), 400

        # Actualizar cabecera
        campos_cabecera = []
        valores_cabecera = []
        if id_tercero:
            campos_cabecera.append("id_tercero = %s")
            valores_cabecera.append(id_tercero)
        if id_usuario:
            campos_cabecera.append("id_usuario = %s")
            valores_cabecera.append(id_usuario)
        if nuevo_estado and nuevo_estado in ESTADOS_VALIDOS_VENTA:
            campos_cabecera.append("estado_venta = %s")
            valores_cabecera.append(nuevo_estado)

        if campos_cabecera:
            valores_cabecera.append(id_venta)
            cursor.execute(f"UPDATE ventas SET {', '.join(campos_cabecera)} WHERE id_venta = %s", tuple(valores_cabecera))

        # Actualizar e insertar detalles
        productos_enviados = set()
        for item in detalles:
            id_prod = int(item['id_producto'])
            cant = int(item['cantidad'])
            precio = float(item['precioUnitario'])
            iva = float(item.get('porcentaje_iva', 0.19))
            productos_enviados.add(id_prod)

            if id_prod in mapa_previos:
                item_prev = mapa_previos[id_prod]
                if item_prev['cantidad'] != cant or float(item_prev['precioUnitario']) != precio or float(item_prev['porcentaje_iva']) != iva:
                    cursor.execute("""
                        UPDATE detalleventa 
                        SET cantidad = %s, precioUnitario = %s, porcentaje_iva = %s
                        WHERE id_detalle_venta = %s
                    """, (cant, precio, iva, item_prev['id_detalle_venta']))
            else:
                cursor.execute("""
                    INSERT INTO detalleventa (id_venta, id_producto, cantidad, precioUnitario, porcentaje_iva)
                    VALUES (%s, %s, %s, %s, %s)
                """, (id_venta, id_prod, cant, precio, iva))

        # Eliminar ítems removidos
        for id_prod, item_prev in mapa_previos.items():
            if id_prod not in productos_enviados:
                cursor.execute("DELETE FROM detalleventa WHERE id_detalle_venta = %s", (item_prev['id_detalle_venta'],))

        conn.commit()

        return jsonify({
            "mensaje": f"Venta #{id_venta} modificada exitosamente.",
            "id_venta": id_venta
        }), 200

    except mysql.connector.Error as err:
        if conn:
            conn.rollback()
        return auditar_error_bd(err, "actualizar_venta")

    finally:
        if cursor:
            cursor.close()
        if conn:
            conn.close()


@ventas_bp.route('/<int:id_venta>/estado', methods=['PUT', 'PATCH'])
def actualizar_estado_venta(id_venta):
    """
    Modifica el estado de una venta.
    """
    datos = request.json
    if not datos:
        return jsonify({"error": "Validación: No se enviaron datos para actualizar el estado."}), 400

    nuevo_estado = datos.get('estado_venta') or datos.get('estado')
    if not nuevo_estado or nuevo_estado not in ESTADOS_VALIDOS_VENTA:
        return jsonify({"error": f"Validación: El estado '{nuevo_estado}' no es válido para una venta."}), 400

    conn = None
    cursor = None
    try:
        conn = get_db_connection()
        cursor = conn.cursor(dictionary=True)

        cursor.execute("SELECT estado_venta FROM ventas WHERE id_venta = %s", (id_venta,))
        v_prev = cursor.fetchone()
        if not v_prev:
            return jsonify({"error": f"Validación: La venta #{id_venta} no existe en el sistema."}), 404

        estado_anterior = v_prev['estado_venta']

        if estado_anterior == 'Anulado':
            return jsonify({"error": "Seguridad: Una venta anulada no puede volver a cambiarse de estado por control fiscal."}), 400

        if estado_anterior == 'Pagado':
            return jsonify({"error": "Seguridad: La venta ya se encuentra pagada y no permite más modificaciones de estado."}), 400

        if nuevo_estado == 'Anulado' and estado_anterior in ('Pagado', 'Enviado'):
            return jsonify({"error": f"Seguridad: No se puede anular una venta que ya ha sido marcada como '{estado_anterior}'."}), 400

        cursor.execute("UPDATE ventas SET estado_venta = %s WHERE id_venta = %s", (nuevo_estado, id_venta))
        conn.commit()

        return jsonify({
            "mensaje": f"Estado de la venta #{id_venta} actualizado a '{nuevo_estado}'.",
            "id_venta": id_venta,
            "estado_venta": nuevo_estado
        }), 200

    except mysql.connector.Error as err:
        if conn:
            conn.rollback()
        return auditar_error_bd(err, "actualizar_estado_venta")

    finally:
        if cursor:
            cursor.close()
        if conn:
            conn.close()


@ventas_bp.route('/<int:id_venta>/anular', methods=['PUT'])
def anular_venta_endpoint(id_venta):
    """
    Punto 1: Cambio de Estados (Reversión de Ventas).
    Anula una transacción actualizando exclusivamente su estado a 'Anulado'.

    Condición Técnica:
    - El endpoint únicamente actualiza el campo de estado a 'Anulado'.
    - El código backend NO calcula devoluciones de stock en Python; delega la restitución
      del inventario al disparador AFTER UPDATE de la base de datos (ventas_AFTER_UPDATE).
    - Captura y devuelve al cliente cualquier error de regla de negocio (SIGNAL SQLSTATE 45000)
      que la base de datos lance si la venta no cumple los requisitos para anularse
      (disparador ventas_BEFORE_UPDATE).
    """
    conn = None
    cursor = None
    try:
        conn = get_db_connection()
        cursor = conn.cursor(dictionary=True)

        cursor.execute("SELECT id_venta FROM ventas WHERE id_venta = %s", (id_venta,))
        venta = cursor.fetchone()
        if not venta:
            return jsonify({"error": f"Validación: La venta #{id_venta} no existe en el sistema."}), 404

        # El backend únicamente actualiza el campo de estado a 'Anulado'
        cursor.execute("UPDATE ventas SET estado_venta = 'Anulado' WHERE id_venta = %s", (id_venta,))
        conn.commit()

        return jsonify({
            "mensaje": f"Venta #{id_venta} anulada exitosamente.",
            "id_venta": id_venta,
            "estado_venta": "Anulado"
        }), 200

    except mysql.connector.Error as err:
        if conn:
            conn.rollback()
        return auditar_error_bd(err, "anular_venta_endpoint")

    finally:
        if cursor:
            cursor.close()
        if conn:
            conn.close()


@ventas_bp.route('/<int:id_venta>', methods=['DELETE'])
def anular_venta(id_venta):
    """
    Compatibilidad hacia atrás para eliminación/anulación lógica de ventas.
    Delega a anular_venta_endpoint para garantizar que no se manipule stock en Python.
    """
    return anular_venta_endpoint(id_venta)

