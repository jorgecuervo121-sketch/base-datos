import mysql.connector
from flask import Blueprint, jsonify, request
from config import get_db_connection, auditar_error_bd

pedidos_bp = Blueprint('pedidos', __name__, url_prefix='/api/pedidos')

_orig_register_pedidos = pedidos_bp.register
def _safe_register_pedidos(app, options):
    if options.get("url_prefix") == pedidos_bp.url_prefix:
        options = dict(options)
        options.pop("url_prefix", None)
    return _orig_register_pedidos(app, options)
pedidos_bp.register = _safe_register_pedidos

ESTADOS_VALIDOS_PEDIDO = {'Pendiente', 'Pagado', 'Anulado', 'Enviado', 'Por Pagar'}


@pedidos_bp.route('/', methods=['GET'])
def obtener_pedidos():
    """
    Consulta el listado general de pedidos u órdenes de compra.
    SQL crudo con cursor en modo diccionario (dictionary=True).
    Auditoría estricta de mysql.connector.Error.
    """
    conn = None
    cursor = None
    try:
        conn = get_db_connection()
        cursor = conn.cursor(dictionary=True)
        sql = """
            SELECT 
                p.id_pedido, 
                p.fecha_pedido, 
                p.total_pedido, 
                p.estado_pedido, 
                p.usuarios_id_usuario AS id_usuario, 
                COALESCE(u.nombre, 'Usuario Desconocido') AS nombre_usuario,
                p.tercero_id_tercero AS id_tercero, 
                COALESCE(t.nombre, 'Tercero Desconocido') AS nombre_tercero
            FROM pedidos p
            LEFT JOIN terceros t ON p.tercero_id_tercero = t.id_tercero
            LEFT JOIN usuarios u ON p.usuarios_id_usuario = u.id_usuario
            ORDER BY p.id_pedido DESC;
        """
        cursor.execute(sql)
        pedidos = cursor.fetchall()
        return jsonify(pedidos), 200
    except mysql.connector.Error as err:
        return auditar_error_bd(err, "obtener_pedidos")
    finally:
        if cursor:
            cursor.close()
        if conn:
            conn.close()


@pedidos_bp.route('/', methods=['POST'])
def crear_pedido():
    """
    Registra un nuevo pedido (Maestro-Detalle).
    Valida previamente proveedores, usuarios, productos activos y cantidades.
    """
    datos = request.json
    if not datos:
        return jsonify({"error": "Validación: No se recibieron datos para el pedido."}), 400

    id_tercero = datos.get('tercero_id_tercero') or datos.get('id_tercero')
    id_usuario = datos.get('usuarios_id_usuario') or datos.get('id_usuario')
    estado_pedido = datos.get('estado_pedido', 'Pendiente')
    detalles = datos.get('detalles', [])

    if not id_tercero or not id_usuario:
        return jsonify({"error": "Validación: Debe seleccionar un proveedor y un usuario solicitante responsable."}), 400

    if not isinstance(detalles, list) or len(detalles) == 0:
        return jsonify({"error": "Validación: El pedido debe contener al menos un producto a ordenar."}), 400

    if estado_pedido not in ESTADOS_VALIDOS_PEDIDO:
        return jsonify({"error": f"Validación: El estado '{estado_pedido}' no es válido para un pedido."}), 400

    conn = None
    cursor = None
    try:
        conn = get_db_connection()
        cursor = conn.cursor(dictionary=True)

        # 1. Validaciones de cada producto antes de insertar
        for item in detalles:
            if 'id_producto' not in item or 'cantidad' not in item or 'precioUnitario' not in item:
                return jsonify({"error": "Validación: Estructura de producto incompleta en los detalles del pedido."}), 400

            try:
                id_prod = int(item['id_producto'])
                cant = int(item['cantidad'])
                precio = float(item['precioUnitario'])
            except (ValueError, TypeError):
                return jsonify({"error": "Validación: La cantidad y el costo deben ser valores numéricos válidos."}), 400

            if cant <= 0:
                return jsonify({"error": "Validación: La cantidad a pedir debe ser un número entero mayor a cero."}), 400

            if precio < 0:
                return jsonify({"error": "Validación: El costo unitario de compra no puede ser un valor negativo."}), 400

            cursor.execute("SELECT id_producto, nombre, estado FROM productos WHERE id_producto = %s", (id_prod,))
            prod = cursor.fetchone()
            if not prod:
                return jsonify({"error": f"Validación: El producto con ID #{id_prod} no existe en el catálogo."}), 404

            if prod['estado'] == 0:
                return jsonify({"error": f"Validación: El producto '{prod['nombre']}' se encuentra inactivo y no puede solicitarse en un pedido."}), 400

        # 2. Insertar cabecera
        sql_pedido = """
            INSERT INTO pedidos (usuarios_id_usuario, tercero_id_tercero, estado_pedido)
            VALUES (%s, %s, %s)
        """
        cursor.execute(sql_pedido, (id_usuario, id_tercero, estado_pedido))
        id_pedido_generado = cursor.lastrowid

        # 3. Insertar detalles
        sql_detalle = """
            INSERT INTO detalle_pedido (id_pedido, id_producto, cantidad, precioUnitario, porcentaje_iva)
            VALUES (%s, %s, %s, %s, %s)
        """

        total_acumulado = 0.0
        for item in detalles:
            cant = int(item['cantidad'])
            precio = float(item['precioUnitario'])
            iva = float(item.get('porcentaje_iva', 0.19))

            cursor.execute(sql_detalle, (id_pedido_generado, int(item['id_producto']), cant, precio, iva))

            # Actualizar costo de compra del producto
            cursor.execute("UPDATE productos SET precioCompra = %s WHERE id_producto = %s", (precio, int(item['id_producto'])))

            total_acumulado += cant * precio * (1.0 + iva)

            # Si el pedido se crea como 'Enviado' o 'Pagado', ingresar existencias
            if estado_pedido in ('Enviado', 'Pagado'):
                cursor.execute("""
                    UPDATE productos 
                    SET cantidad_stock = cantidad_stock + %s
                    WHERE id_producto = %s
                """, (cant, int(item['id_producto'])))

        cursor.execute("UPDATE pedidos SET total_pedido = %s WHERE id_pedido = %s", (total_acumulado, id_pedido_generado))
        conn.commit()

        return jsonify({
            "mensaje": f"Pedido #{id_pedido_generado} registrado exitosamente.",
            "id_pedido": id_pedido_generado
        }), 201

    except mysql.connector.Error as err:
        if conn:
            conn.rollback()
        return auditar_error_bd(err, "crear_pedido")

    finally:
        if cursor:
            cursor.close()
        if conn:
            conn.close()


@pedidos_bp.route('/<int:id_pedido>', methods=['GET'])
def obtener_pedido_completo(id_pedido):
    """
    Extrae la cabecera del pedido y su desglose de productos.
    """
    conn = None
    cursor = None
    try:
        conn = get_db_connection()
        cursor = conn.cursor(dictionary=True)

        sql_cabecera = """
            SELECT 
                p.id_pedido, 
                p.fecha_pedido, 
                p.total_pedido, 
                p.estado_pedido, 
                p.usuarios_id_usuario AS id_usuario, 
                COALESCE(u.nombre, 'Usuario Desconocido') AS nombre_usuario,
                p.tercero_id_tercero AS id_tercero, 
                COALESCE(t.nombre, 'Tercero Desconocido') AS nombre_tercero
            FROM pedidos p
            LEFT JOIN terceros t ON p.tercero_id_tercero = t.id_tercero
            LEFT JOIN usuarios u ON p.usuarios_id_usuario = u.id_usuario
            WHERE p.id_pedido = %s
        """
        cursor.execute(sql_cabecera, (id_pedido,))
        pedido = cursor.fetchone()

        if not pedido:
            return jsonify({"error": f"Validación: El pedido #{id_pedido} no fue encontrado en el sistema."}), 404

        sql_detalles = """
            SELECT 
                dp.id_detalle_pedido, 
                dp.id_producto, 
                p.nombre AS nombre_producto, 
                dp.cantidad, 
                dp.precioUnitario, 
                dp.subtotal, 
                dp.porcentaje_iva, 
                dp.total_producto
            FROM detalle_pedido dp
            INNER JOIN productos p ON dp.id_producto = p.id_producto
            WHERE dp.id_pedido = %s
        """
        cursor.execute(sql_detalles, (id_pedido,))
        pedido['detalles'] = cursor.fetchall()

        return jsonify(pedido), 200

    except mysql.connector.Error as err:
        return auditar_error_bd(err, "obtener_pedido_completo")

    finally:
        if cursor:
            cursor.close()
        if conn:
            conn.close()


@pedidos_bp.route('/<int:id_pedido>', methods=['PUT'])
def actualizar_pedido(id_pedido):
    """
    Modifica un pedido completo (Cabecera y Maestro-Detalle).
    """
    datos = request.json
    if not datos:
        return jsonify({"error": "Validación: No se recibieron datos para actualizar el pedido."}), 400

    if 'detalles' not in datos and ('estado_pedido' in datos or 'estado' in datos):
        return actualizar_estado_pedido(id_pedido)

    detalles = datos.get('detalles')
    if not isinstance(detalles, list) or len(detalles) == 0:
        return jsonify({"error": "Validación: El pedido debe contener al menos un producto en el detalle."}), 400

    id_tercero = datos.get('tercero_id_tercero') or datos.get('id_tercero')
    id_usuario = datos.get('usuarios_id_usuario') or datos.get('id_usuario')
    nuevo_estado = datos.get('estado_pedido')

    conn = None
    cursor = None
    try:
        conn = get_db_connection()
        cursor = conn.cursor(dictionary=True)

        cursor.execute("SELECT estado_pedido FROM pedidos WHERE id_pedido = %s", (id_pedido,))
        pedido_actual = cursor.fetchone()
        if not pedido_actual:
            return jsonify({"error": f"Validación: El pedido #{id_pedido} no existe en el sistema."}), 404

        if pedido_actual['estado_pedido'] in ('Pagado', 'Enviado', 'Anulado'):
            return jsonify({"error": f"Seguridad: No se puede modificar un pedido que ya ha sido marcado como '{pedido_actual['estado_pedido']}'."}), 400

        # Validaciones de cada producto
        for item in detalles:
            if 'id_producto' not in item or 'cantidad' not in item or 'precioUnitario' not in item:
                return jsonify({"error": "Validación: Estructura de producto incompleta en los detalles del pedido."}), 400

            try:
                id_prod = int(item['id_producto'])
                cant = int(item['cantidad'])
                precio = float(item['precioUnitario'])
            except (ValueError, TypeError):
                return jsonify({"error": "Validación: La cantidad y el costo deben ser valores numéricos válidos."}), 400

            if cant <= 0:
                return jsonify({"error": "Validación: La cantidad de cada producto debe ser mayor a cero."}), 400

            if precio < 0:
                return jsonify({"error": "Validación: El costo unitario de compra no puede ser un valor negativo."}), 400

            cursor.execute("SELECT nombre, estado FROM productos WHERE id_producto = %s", (id_prod,))
            prod = cursor.fetchone()
            if not prod:
                return jsonify({"error": f"Validación: El producto con ID #{id_prod} no existe en el catálogo."}), 404

            if prod['estado'] == 0:
                return jsonify({"error": f"Validación: El producto '{prod['nombre']}' se encuentra inactivo y no puede agregarse a un pedido."}), 400

        # Actualizar cabecera
        campos_cabecera = []
        valores_cabecera = []
        if id_tercero:
            campos_cabecera.append("tercero_id_tercero = %s")
            valores_cabecera.append(id_tercero)
        if id_usuario:
            campos_cabecera.append("usuarios_id_usuario = %s")
            valores_cabecera.append(id_usuario)
        if nuevo_estado and nuevo_estado in ESTADOS_VALIDOS_PEDIDO:
            if nuevo_estado == 'Anulado' and pedido_actual['estado_pedido'] in ('Pagado', 'Enviado'):
                return jsonify({"error": f"Seguridad: No se puede anular un pedido que ya ha sido procesado como '{pedido_actual['estado_pedido']}'."}), 400
            campos_cabecera.append("estado_pedido = %s")
            valores_cabecera.append(nuevo_estado)

        if campos_cabecera:
            valores_cabecera.append(id_pedido)
            cursor.execute(f"UPDATE pedidos SET {', '.join(campos_cabecera)} WHERE id_pedido = %s", tuple(valores_cabecera))

        cursor.execute("SELECT id_detalle_pedido, id_producto, cantidad, precioUnitario, porcentaje_iva FROM detalle_pedido WHERE id_pedido = %s", (id_pedido,))
        detalles_previos = cursor.fetchall()
        mapa_previos = {d['id_producto']: d for d in detalles_previos}

        productos_enviados = set()
        for item in detalles:
            id_prod = int(item['id_producto'])
            cant = int(item['cantidad'])
            precio = float(item['precioUnitario'])
            iva = float(item.get('porcentaje_iva', 0.19))
            productos_enviados.add(id_prod)

            if id_prod in mapa_previos:
                item_prev = mapa_previos[id_prod]
                if item_prev['cantidad'] != cant or float(item_prev['precioUnitario']) != precio or float(item_prev['porcentaje_iva']) != iva:
                    cursor.execute("""
                        UPDATE detalle_pedido 
                        SET cantidad = %s, precioUnitario = %s, porcentaje_iva = %s
                        WHERE id_detalle_pedido = %s
                    """, (cant, precio, iva, item_prev['id_detalle_pedido']))
                    cursor.execute("UPDATE productos SET precioCompra = %s WHERE id_producto = %s", (precio, id_prod))
            else:
                cursor.execute("""
                    INSERT INTO detalle_pedido (id_pedido, id_producto, cantidad, precioUnitario, porcentaje_iva)
                    VALUES (%s, %s, %s, %s, %s)
                """, (id_pedido, id_prod, cant, precio, iva))
                cursor.execute("UPDATE productos SET precioCompra = %s WHERE id_producto = %s", (precio, id_prod))

        for id_prod, item_prev in mapa_previos.items():
            if id_prod not in productos_enviados:
                cursor.execute("DELETE FROM detalle_pedido WHERE id_detalle_pedido = %s", (item_prev['id_detalle_pedido'],))

        cursor.execute("""
            UPDATE pedidos 
            SET total_pedido = COALESCE((
                SELECT SUM(cantidad * precioUnitario * (1 + porcentaje_iva)) 
                FROM detalle_pedido 
                WHERE id_pedido = %s
            ), 0)
            WHERE id_pedido = %s
        """, (id_pedido, id_pedido))

        conn.commit()

        return jsonify({
            "mensaje": f"Pedido #{id_pedido} modificado exitosamente.",
            "id_pedido": id_pedido
        }), 200

    except mysql.connector.Error as err:
        if conn:
            conn.rollback()
        return auditar_error_bd(err, "actualizar_pedido")

    finally:
        if cursor:
            cursor.close()
        if conn:
            conn.close()


@pedidos_bp.route('/<int:id_pedido>/estado', methods=['PUT', 'PATCH'])
def actualizar_estado_pedido(id_pedido):
    """
    Actualiza el estado de un pedido.
    """
    datos = request.json
    if not datos:
        return jsonify({"error": "Validación: No se enviaron datos para actualizar el estado."}), 400

    nuevo_estado = datos.get('estado_pedido') or datos.get('estado')
    if not nuevo_estado or nuevo_estado not in ESTADOS_VALIDOS_PEDIDO:
        return jsonify({"error": f"Validación: El estado '{nuevo_estado}' no es válido para un pedido."}), 400

    conn = None
    cursor = None
    try:
        conn = get_db_connection()
        cursor = conn.cursor(dictionary=True)

        cursor.execute("SELECT estado_pedido FROM pedidos WHERE id_pedido = %s", (id_pedido,))
        pedido_previo = cursor.fetchone()
        if not pedido_previo:
            return jsonify({"error": f"Validación: El pedido #{id_pedido} no existe en el sistema."}), 404

        estado_anterior = pedido_previo['estado_pedido']

        if estado_anterior == 'Anulado':
            return jsonify({"error": "Seguridad: Un pedido anulado no puede volver a cambiarse de estado por control contable."}), 400

        if estado_anterior == 'Pagado':
            return jsonify({"error": "Seguridad: El pedido ya se encuentra pagado y no permite más modificaciones de estado."}), 400

        if estado_anterior == 'Enviado' and nuevo_estado != 'Pagado':
            return jsonify({"error": "Seguridad: Un pedido en estado 'Enviado' únicamente puede transicionar al estado 'Pagado'."}), 400

        if nuevo_estado == 'Anulado' and estado_anterior in ('Pagado', 'Enviado'):
            return jsonify({"error": f"Seguridad: No se puede anular un pedido que ya ha sido marcado como '{estado_anterior}'."}), 400

        cursor.execute("UPDATE pedidos SET estado_pedido = %s WHERE id_pedido = %s", (nuevo_estado, id_pedido))

        # Ingresar existencias si pasa a Enviado o Pagado
        if estado_anterior in ('Pendiente', 'Por Pagar') and nuevo_estado in ('Enviado', 'Pagado'):
            cursor.execute("""
                UPDATE productos p
                INNER JOIN detalle_pedido dp ON p.id_producto = dp.id_producto
                SET p.cantidad_stock = p.cantidad_stock + dp.cantidad
                WHERE dp.id_pedido = %s
            """, (id_pedido,))

        conn.commit()

        return jsonify({
            "mensaje": f"Estado del pedido #{id_pedido} actualizado a '{nuevo_estado}'.",
            "id_pedido": id_pedido,
            "estado_pedido": nuevo_estado
        }), 200

    except mysql.connector.Error as err:
        if conn:
            conn.rollback()
        return auditar_error_bd(err, "actualizar_estado_pedido")

    finally:
        if cursor:
            cursor.close()
        if conn:
            conn.close()


@pedidos_bp.route('/<int:id_pedido>', methods=['DELETE'])
def anular_pedido(id_pedido):
    """
    Anula un pedido en lugar de borrarlo físicamente para trazabilidad.
    """
    conn = None
    cursor = None
    try:
        conn = get_db_connection()
        cursor = conn.cursor(dictionary=True)

        cursor.execute("SELECT estado_pedido FROM pedidos WHERE id_pedido = %s", (id_pedido,))
        pedido = cursor.fetchone()
        if not pedido:
            return jsonify({"error": f"Validación: El pedido #{id_pedido} no existe en el sistema."}), 404

        if pedido['estado_pedido'] in ('Pagado', 'Enviado'):
            return jsonify({"error": f"Seguridad: No se puede anular un pedido que ya ha sido marcado como '{pedido['estado_pedido']}'."}), 400

        if pedido['estado_pedido'] == 'Anulado':
            return jsonify({"error": "Validación: El pedido ya se encuentra anulado."}), 400

        cursor.execute("UPDATE pedidos SET estado_pedido = 'Anulado' WHERE id_pedido = %s", (id_pedido,))
        conn.commit()

        return jsonify({
            "mensaje": f"Pedido #{id_pedido} anulado correctamente.",
            "id_pedido": id_pedido,
            "estado_pedido": "Anulado"
        }), 200

    except mysql.connector.Error as err:
        if conn:
            conn.rollback()
        return auditar_error_bd(err, "anular_pedido")

    finally:
        if cursor:
            cursor.close()
        if conn:
            conn.close()
