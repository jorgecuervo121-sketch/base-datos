import mysql.connector
from flask import Blueprint, jsonify, request
from config import get_db_connection, auditar_error_bd

terceros_bp = Blueprint('terceros', __name__, url_prefix='/api/terceros')

_orig_register_terceros = terceros_bp.register
def _safe_register_terceros(app, options):
    if options.get("url_prefix") == terceros_bp.url_prefix:
        options = dict(options)
        options.pop("url_prefix", None)
    return _orig_register_terceros(app, options)
terceros_bp.register = _safe_register_terceros


@terceros_bp.route('/', methods=['GET'])
def obtener_terceros():
    """
    Consulta el listado de terceros activos (clientes y proveedores).
    SQL crudo con cursor en modo diccionario (dictionary=True).
    Auditoría estricta de mysql.connector.Error.
    """
    conn = None
    cursor = None
    try:
        conn = get_db_connection()
        cursor = conn.cursor(dictionary=True)
        cursor.execute("SELECT id_tercero, nombre, correo, contacto, estado FROM terceros WHERE estado = 1 ORDER BY nombre ASC;")
        terceros = cursor.fetchall()
        return jsonify(terceros), 200
    except mysql.connector.Error as err:
        return auditar_error_bd(err, "obtener_terceros")
    finally:
        if cursor:
            cursor.close()
        if conn:
            conn.close()


@terceros_bp.route('/', methods=['POST'])
def crear_tercero():
    """
    Registra un nuevo tercero en el sistema.
    """
    datos = request.json
    if not datos or 'nombre' not in datos or 'correo' not in datos or 'contacto' not in datos:
        return jsonify({"error": "Validación: Los campos 'nombre', 'correo' y 'contacto' son obligatorios para crear el tercero."}), 400

    nombre = str(datos['nombre']).strip()
    correo = str(datos['correo']).strip()
    contacto = str(datos['contacto']).strip()

    if not nombre:
        return jsonify({"error": "Validación: El nombre o razón social del tercero no puede estar vacío."}), 400

    if not correo or '@' not in correo:
        return jsonify({"error": "Validación: Ingrese una dirección de correo electrónico válida (ej: contacto@empresa.com)."}), 400

    if not contacto:
        return jsonify({"error": "Validación: El número telefónico de contacto es obligatorio."}), 400

    conn = None
    cursor = None
    try:
        conn = get_db_connection()
        cursor = conn.cursor(dictionary=True)

        sql = """
            INSERT INTO terceros (nombre, correo, contacto, estado)
            VALUES (%s, %s, %s, 1)
        """
        cursor.execute(sql, (nombre, correo, contacto))
        conn.commit()

        id_nuevo = cursor.lastrowid
        return jsonify({
            "mensaje": f"Tercero '{nombre}' registrado exitosamente con ID #{id_nuevo}.",
            "id_tercero": id_nuevo
        }), 201

    except mysql.connector.Error as err:
        if conn:
            conn.rollback()
        return auditar_error_bd(err, "crear_tercero")

    finally:
        if cursor:
            cursor.close()
        if conn:
            conn.close()


@terceros_bp.route('/<int:id_tercero>', methods=['PUT'])
def actualizar_tercero(id_tercero):
    """
    Actualiza la información completa de un tercero.
    """
    datos = request.json
    if not datos or 'nombre' not in datos or 'correo' not in datos or 'contacto' not in datos:
        return jsonify({"error": "Validación: Los campos 'nombre', 'correo' y 'contacto' son obligatorios para actualizar el tercero."}), 400

    nombre = str(datos['nombre']).strip()
    correo = str(datos['correo']).strip()
    contacto = str(datos['contacto']).strip()

    if not nombre:
        return jsonify({"error": "Validación: El nombre o razón social no puede quedar en blanco."}), 400

    if not correo or '@' not in correo:
        return jsonify({"error": "Validación: Ingrese una dirección de correo electrónico válida."}), 400

    if not contacto:
        return jsonify({"error": "Validación: El número telefónico de contacto no puede quedar en blanco."}), 400

    conn = None
    cursor = None
    try:
        conn = get_db_connection()
        cursor = conn.cursor(dictionary=True)

        sql = """
            UPDATE terceros
            SET nombre = %s,
                correo = %s,
                contacto = %s
            WHERE id_tercero = %s
        """
        valores = (nombre, correo, contacto, id_tercero)
        cursor.execute(sql, valores)
        conn.commit()

        if cursor.rowcount == 0:
            return jsonify({"mensaje": f"Validación: No se detectaron modificaciones o el tercero #{id_tercero} no existe."}), 404

        return jsonify({"mensaje": f"Tercero #{id_tercero} actualizado correctamente."}), 200

    except mysql.connector.Error as err:
        if conn:
            conn.rollback()
        return auditar_error_bd(err, "actualizar_tercero")

    finally:
        if cursor:
            cursor.close()
        if conn:
            conn.close()


@terceros_bp.route('/<int:id_tercero>', methods=['PATCH'])
def actualizar_parcial_tercero(id_tercero):
    """
    Actualiza campos específicos de un tercero.
    """
    datos = request.json
    if not datos:
        return jsonify({"error": "Validación: No se enviaron datos para actualizar el tercero."}), 400

    campos_permitidos = ['nombre', 'correo', 'contacto', 'estado']
    campos_a_actualizar = []
    valores = []

    for campo in campos_permitidos:
        if campo in datos:
            campos_a_actualizar.append(f"{campo} = %s")
            valores.append(datos[campo])

    if not campos_a_actualizar:
        return jsonify({"error": "Validación: No se enviaron campos válidos para actualizar."}), 400

    valores.append(id_tercero)
    sql = f"UPDATE terceros SET {', '.join(campos_a_actualizar)} WHERE id_tercero = %s"

    conn = None
    cursor = None
    try:
        conn = get_db_connection()
        cursor = conn.cursor(dictionary=True)
        cursor.execute(sql, tuple(valores))
        conn.commit()

        if cursor.rowcount == 0:
            return jsonify({"mensaje": f"Validación: No se realizaron cambios o el tercero #{id_tercero} no existe."}), 404

        return jsonify({"mensaje": f"Tercero #{id_tercero} actualizado parcialmente con éxito."}), 200

    except mysql.connector.Error as err:
        if conn:
            conn.rollback()
        return auditar_error_bd(err, "actualizar_parcial_tercero")

    finally:
        if cursor:
            cursor.close()
        if conn:
            conn.close()


@terceros_bp.route('/<int:id_tercero>', methods=['DELETE'])
def eliminar_tercero(id_tercero):
    """
    Inactiva un tercero (Soft Delete) validando que no tenga ventas ni pedidos vinculados.
    """
    conn = None
    cursor = None
    try:
        conn = get_db_connection()
        cursor = conn.cursor(dictionary=True)

        cursor.execute("SELECT id_tercero, nombre FROM terceros WHERE id_tercero = %s", (id_tercero,))
        tercero = cursor.fetchone()
        if not tercero:
            return jsonify({"error": f"Validación: El tercero #{id_tercero} no existe en el directorio."}), 404

        cursor.execute("SELECT COUNT(*) AS cant_ventas FROM ventas WHERE id_tercero = %s", (id_tercero,))
        v = cursor.fetchone()
        if v and v['cant_ventas'] > 0:
            return jsonify({"error": f"Seguridad: No se puede inactivar el tercero '{tercero['nombre']}' porque cuenta con ventas registradas en el sistema."}), 400

        cursor.execute("SELECT COUNT(*) AS cant_pedidos FROM pedidos WHERE tercero_id_tercero = %s", (id_tercero,))
        p = cursor.fetchone()
        if p and p['cant_pedidos'] > 0:
            return jsonify({"error": f"Seguridad: No se puede inactivar el tercero '{tercero['nombre']}' porque cuenta con pedidos u órdenes de compra registradas."}), 400

        cursor.execute("UPDATE terceros SET estado = 0 WHERE id_tercero = %s", (id_tercero,))
        conn.commit()

        return jsonify({"mensaje": f"Tercero '{tercero['nombre']}' (#{id_tercero}) inactivado correctamente."}), 200

    except mysql.connector.Error as err:
        if conn:
            conn.rollback()
        return auditar_error_bd(err, "eliminar_tercero")

    finally:
        if cursor:
            cursor.close()
        if conn:
            conn.close()
