import mysql.connector
from flask import Blueprint, jsonify, request
from config import get_db_connection, auditar_error_bd

usuarios_bp = Blueprint('usuarios', __name__, url_prefix='/api/usuarios')

_orig_register_usuarios = usuarios_bp.register
def _safe_register_usuarios(app, options):
    if options.get("url_prefix") == usuarios_bp.url_prefix:
        options = dict(options)
        options.pop("url_prefix", None)
    return _orig_register_usuarios(app, options)
usuarios_bp.register = _safe_register_usuarios


@usuarios_bp.route('/', methods=['GET'])
def obtener_usuarios():
    """
    Retorna la lista de usuarios activos para asignar a ventas y pedidos.
    SQL crudo con cursor en modo diccionario (dictionary=True).
    Auditoría estricta de mysql.connector.Error.
    """
    conn = None
    cursor = None
    try:
        conn = get_db_connection()
        cursor = conn.cursor(dictionary=True)
        
        cursor.execute("SELECT id_usuario, nombre, correo, estado FROM usuarios WHERE estado = 1 ORDER BY nombre ASC;")
        usuarios = cursor.fetchall()

        if not usuarios:
            cursor.execute("""
                INSERT INTO usuarios (id_usuario, nombre, correo, password, estado, roles_id_rol)
                VALUES (1, 'Administrador Principal', 'admin@erp.com', 'admin123', 1, 1)
                ON DUPLICATE KEY UPDATE estado = 1;
            """)
            conn.commit()
            cursor.execute("SELECT id_usuario, nombre, correo, estado FROM usuarios WHERE estado = 1;")
            usuarios = cursor.fetchall()

        return jsonify(usuarios), 200
    except mysql.connector.Error as err:
        return auditar_error_bd(err, "obtener_usuarios")
    finally:
        if cursor:
            cursor.close()
        if conn:
            conn.close()
