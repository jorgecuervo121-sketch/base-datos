# Paquete de rutas de la API (Blueprints)
from .productos import productos_bp
from .terceros import terceros_bp
from .ventas import ventas_bp
from .pedidos import pedidos_bp
from .usuarios import usuarios_bp

__all__ = ['productos_bp', 'terceros_bp', 'ventas_bp', 'pedidos_bp', 'usuarios_bp']
