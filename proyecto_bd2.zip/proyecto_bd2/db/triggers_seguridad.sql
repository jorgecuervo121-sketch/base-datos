-- ============================================================================
-- SCRIPT COMPLETO DE TRIGGERS DE SEGURIDAD Y CONTROL DE STOCK
-- Base de Datos: erp (MySQL Workbench)
-- ============================================================================
-- Instrucciones: Ejecutar este script conectado como root o usuario con privilegios
-- en MySQL Workbench para garantizar la integridad referencial y de inventario.
-- ============================================================================

USE `erp`;

-- Habilitar creación de rutinas/triggers si binary logging está activo
SET GLOBAL log_bin_trust_function_creators = 1;

-- ----------------------------------------------------------------------------
-- 1. SEGURIDAD: Evitar borrado físico de Ventas procesadas o con detalles
-- ----------------------------------------------------------------------------
DROP TRIGGER IF EXISTS `ventas_BEFORE_DELETE`;
DELIMITER $$
CREATE TRIGGER `ventas_BEFORE_DELETE` BEFORE DELETE ON `ventas` FOR EACH ROW 
BEGIN
    IF OLD.estado_venta IN ('Pagado', 'Enviado', 'Por Pagar') THEN
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = 'Seguridad: No se puede eliminar una venta procesada. Debe anularse.';
    END IF;

    IF EXISTS (SELECT 1 FROM detalleventa WHERE id_venta = OLD.id_venta) THEN
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = 'Seguridad: No se puede eliminar la venta porque contiene productos facturados.';
    END IF;
END$$
DELIMITER ;

-- ----------------------------------------------------------------------------
-- 2. SEGURIDAD: Control de modificaciones en estado de Ventas
-- ----------------------------------------------------------------------------
DROP TRIGGER IF EXISTS `ventas_BEFORE_UPDATE`;
DELIMITER $$
CREATE TRIGGER `ventas_BEFORE_UPDATE` BEFORE UPDATE ON `ventas` FOR EACH ROW 
BEGIN
    -- Una venta anulada no puede reactivarse
    IF OLD.estado_venta = 'Anulado' THEN
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = 'Seguridad: Una venta anulada no puede volver a modificarse por trazabilidad contable.';
    END IF;

    -- No permitir anular ventas ya entregadas o pagadas sin procedimiento de devolución
    IF NEW.estado_venta = 'Anulado' AND OLD.estado_venta IN ('Pagado', 'Enviado') THEN
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = 'Seguridad: No se puede anular una venta que ya fue procesada o pagada.';
    END IF;
END$$
DELIMITER ;

-- ----------------------------------------------------------------------------
-- 3. STOCK: Reponer inventario automáticamente al anular una venta
-- ----------------------------------------------------------------------------
DROP TRIGGER IF EXISTS `ventas_AFTER_UPDATE`;
DELIMITER $$
CREATE TRIGGER `ventas_AFTER_UPDATE` AFTER UPDATE ON `ventas` FOR EACH ROW 
BEGIN
    -- Cuando la venta pasa a 'Anulado', devolver la mercancía al inventario
    IF NEW.estado_venta = 'Anulado' AND OLD.estado_venta <> 'Anulado' THEN
        UPDATE productos p
        INNER JOIN detalleventa dv ON p.id_producto = dv.id_producto
        SET p.cantidad_stock = p.cantidad_stock + dv.cantidad
        WHERE dv.id_venta = NEW.id_venta;
    END IF;
END$$
DELIMITER ;

-- ----------------------------------------------------------------------------
-- 4. SEGURIDAD: Evitar borrado físico de Pedidos procesados o con detalles
-- ----------------------------------------------------------------------------
DROP TRIGGER IF EXISTS `pedidos_BEFORE_DELETE`;
DELIMITER $$
CREATE TRIGGER `pedidos_BEFORE_DELETE` BEFORE DELETE ON `pedidos` FOR EACH ROW 
BEGIN
    IF OLD.estado_pedido IN ('Pagado', 'Enviado') THEN
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = 'Seguridad: No se puede eliminar un pedido que ya fue procesado o enviado.';
    END IF;

    IF EXISTS (SELECT 1 FROM detalle_pedido WHERE id_pedido = OLD.id_pedido) THEN
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = 'Seguridad: No se puede eliminar el pedido porque contiene productos en su detalle.';
    END IF;
END$$
DELIMITER ;

-- ----------------------------------------------------------------------------
-- 5. SEGURIDAD: Control de modificaciones en estado de Pedidos
-- ----------------------------------------------------------------------------
DROP TRIGGER IF EXISTS `pedidos_BEFORE_UPDATE`;
DELIMITER $$
CREATE TRIGGER `pedidos_BEFORE_UPDATE` BEFORE UPDATE ON `pedidos` FOR EACH ROW 
BEGIN
    -- Un pedido anulado no puede volver a cambiarse
    IF OLD.estado_pedido = 'Anulado' THEN
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = 'Seguridad: Un pedido anulado no puede volver a cambiarse de estado por seguridad contable.';
    END IF;

    -- REGLA: Cuando el pedido ya es 'Pagado', no se puede modificar más
    IF OLD.estado_pedido = 'Pagado' AND NEW.estado_pedido <> 'Pagado' THEN
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = 'Seguridad: El pedido ya se encuentra pagado y no permite más modificaciones.';
    END IF;

    -- REGLA: Cuando el pedido es 'Enviado', solo se puede modificar a 'Pagado'
    IF OLD.estado_pedido = 'Enviado' AND NEW.estado_pedido NOT IN ('Enviado', 'Pagado') THEN
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = 'Seguridad: Un pedido en estado Enviado únicamente puede modificarse a Pagado.';
    END IF;

    -- No se puede anular un pedido que ya fue procesado o enviado
    IF NEW.estado_pedido = 'Anulado' AND OLD.estado_pedido IN ('Pagado', 'Enviado') THEN
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = 'Seguridad: No se puede anular un pedido que ya fue procesado o enviado.';
    END IF;
END$$
DELIMITER ;

-- ----------------------------------------------------------------------------
-- 6. STOCK: Incrementar stock al enviar, pagar o cancelar/anular pedido
-- ----------------------------------------------------------------------------
DROP TRIGGER IF EXISTS `pedidos_AFTER_UPDATE`;
DELIMITER $$
CREATE TRIGGER `pedidos_AFTER_UPDATE` AFTER UPDATE ON `pedidos` FOR EACH ROW 
BEGIN
    -- Incrementa stock cuando el pedido pasa a Enviado, Pagado o Anulado (cancelado)
    -- proviniendo de Pendiente o Por Pagar (solo una vez para evitar duplicaciones)
    IF NEW.estado_pedido IN ('Enviado', 'Pagado', 'Anulado') 
       AND OLD.estado_pedido IN ('Pendiente', 'Por Pagar') THEN
        UPDATE productos p
        INNER JOIN detalle_pedido dp ON p.id_producto = dp.id_producto
        SET p.cantidad_stock = p.cantidad_stock + dp.cantidad
        WHERE dp.id_pedido = NEW.id_pedido;
    END IF;
END$$
DELIMITER ;

-- ----------------------------------------------------------------------------
-- 7. STOCK & COSTO: Registro de items en pedidos
-- ----------------------------------------------------------------------------
DROP TRIGGER IF EXISTS `detalle_pedido_AFTER_INSERT`;
DELIMITER $$
CREATE TRIGGER `detalle_pedido_AFTER_INSERT` AFTER INSERT ON `detalle_pedido` FOR EACH ROW 
BEGIN
    DECLARE v_estado VARCHAR(20);
    
    -- Consulta el estado del pedido asociado
    SELECT estado_pedido INTO v_estado FROM pedidos WHERE id_pedido = NEW.id_pedido;

    -- Actualiza el costo unitario de compra del producto
    UPDATE productos 
    SET precioCompra = NEW.precioUnitario
    WHERE id_producto = NEW.id_producto;

    -- Si el pedido se creó directamente como Enviado, Pagado o Anulado, suma stock
    IF v_estado IN ('Enviado', 'Pagado', 'Anulado') THEN
        UPDATE productos 
        SET cantidad_stock = cantidad_stock + NEW.cantidad
        WHERE id_producto = NEW.id_producto;
    END IF;

    -- Actualiza el total acumulado en la cabecera del pedido
    UPDATE pedidos 
    SET total_pedido = total_pedido + ((NEW.cantidad * NEW.precioUnitario) * (1 + NEW.porcentaje_iva))
    WHERE id_pedido = NEW.id_pedido;
END$$
DELIMITER ;

-- ----------------------------------------------------------------------------
-- 8. SEGURIDAD: Evitar borrado físico de Productos con stock o historial
-- ----------------------------------------------------------------------------
DROP TRIGGER IF EXISTS `productos_BEFORE_DELETE`;
DELIMITER $$
CREATE TRIGGER `productos_BEFORE_DELETE` BEFORE DELETE ON `productos` FOR EACH ROW 
BEGIN
    IF OLD.cantidad_stock > 0 THEN
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = 'Seguridad: No se puede eliminar el producto porque aún cuenta con stock en inventario.';
    END IF;

    IF EXISTS (SELECT 1 FROM detalleventa WHERE id_producto = OLD.id_producto) THEN
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = 'Seguridad: No se puede eliminar el producto porque tiene ventas históricas asociadas.';
    END IF;

    IF EXISTS (SELECT 1 FROM detalle_pedido WHERE id_producto = OLD.id_producto) THEN
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = 'Seguridad: No se puede eliminar el producto porque está vinculado a pedidos existentes.';
    END IF;
END$$
DELIMITER ;

-- ----------------------------------------------------------------------------
-- 9. SEGURIDAD: Evitar borrado físico de Terceros con historial
-- ----------------------------------------------------------------------------
DROP TRIGGER IF EXISTS `terceros_BEFORE_DELETE`;
DELIMITER $$
CREATE TRIGGER `terceros_BEFORE_DELETE` BEFORE DELETE ON `terceros` FOR EACH ROW 
BEGIN
    IF EXISTS (SELECT 1 FROM ventas WHERE id_tercero = OLD.id_tercero) THEN
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = 'Seguridad: No se puede eliminar el tercero porque tiene ventas registradas.';
    END IF;

    IF EXISTS (SELECT 1 FROM pedidos WHERE tercero_id_tercero = OLD.id_tercero) THEN
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = 'Seguridad: No se puede eliminar el tercero porque tiene pedidos registrados.';
    END IF;
END$$
DELIMITER ;

-- ----------------------------------------------------------------------------
-- 10. SEGURIDAD: Evitar borrado físico de Usuarios con historial
-- ----------------------------------------------------------------------------
DROP TRIGGER IF EXISTS `usuarios_BEFORE_DELETE`;
DELIMITER $$
CREATE TRIGGER `usuarios_BEFORE_DELETE` BEFORE DELETE ON `usuarios` FOR EACH ROW 
BEGIN
    IF EXISTS (SELECT 1 FROM ventas WHERE id_usuario = OLD.id_usuario) THEN
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = 'Seguridad: No se puede eliminar el usuario porque ha registrado ventas en el sistema.';
    END IF;

    IF EXISTS (SELECT 1 FROM pedidos WHERE usuarios_id_usuario = OLD.id_usuario) THEN
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = 'Seguridad: No se puede eliminar el usuario porque ha registrado pedidos en el sistema.';
    END IF;
END$$
DELIMITER ;


-- ----------------------------------------------------------------------------
-- 11. DETALLE DE VENTAS: Control de inventario y montos al modificar ventas
-- ----------------------------------------------------------------------------
DROP TRIGGER IF EXISTS `detalleventa_BEFORE_UPDATE`;
DELIMITER $$
CREATE TRIGGER `detalleventa_BEFORE_UPDATE` BEFORE UPDATE ON `detalleventa` FOR EACH ROW 
BEGIN
    DECLARE estado_actual VARCHAR(20);
    DECLARE stock_disponible INT;
    DECLARE costo DECIMAL(12,2);
    
    -- No permitir modificar ventas finalizadas o anuladas
    SELECT estado_venta INTO estado_actual FROM ventas WHERE id_venta = NEW.id_venta;
    IF estado_actual IN ('Anulado', 'Pagado', 'Enviado') THEN
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = 'Seguridad: No se puede modificar una venta que ya ha sido Anulada, Pagada o Enviada.';
    END IF;
    
    -- Validar que el precio de venta cubra el costo de adquisición
    SELECT precioCompra INTO costo FROM productos WHERE id_producto = NEW.id_producto;
    IF NEW.precioUnitario < costo THEN
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = 'Validación: El precio de venta no puede ser menor al costo de compra.';
    END IF;
    
    IF NEW.cantidad <= 0 THEN
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = 'Validación: La cantidad ingresada debe ser mayor a cero.';
    END IF;
    
    -- Si se incrementa la cantidad solicitada, verificar existencias disponibles en almacén
    SELECT cantidad_stock INTO stock_disponible FROM productos WHERE id_producto = NEW.id_producto;
    IF (NEW.cantidad - OLD.cantidad) > stock_disponible THEN
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = 'Stock insuficiente: La cantidad adicional requerida supera el inventario disponible.';
    END IF;
END$$
DELIMITER ;

DROP TRIGGER IF EXISTS `detalleventa_AFTER_UPDATE`;
DELIMITER $$
CREATE TRIGGER `detalleventa_AFTER_UPDATE` AFTER UPDATE ON `detalleventa` FOR EACH ROW 
BEGIN
    -- Recalcular total acumulado en cabecera de la venta
    UPDATE ventas 
    SET total_venta = total_venta 
        - (OLD.cantidad * OLD.precioUnitario * (1 + OLD.porcentaje_iva))
        + (NEW.cantidad * NEW.precioUnitario * (1 + NEW.porcentaje_iva))
    WHERE id_venta = NEW.id_venta;
    
    -- Ajustar inventario automáticamente (si se pide más, descuenta; si se pide menos, repone)
    UPDATE productos
    SET cantidad_stock = (cantidad_stock + OLD.cantidad) - NEW.cantidad 
    WHERE id_producto = NEW.id_producto;
END$$
DELIMITER ;

-- ----------------------------------------------------------------------------
-- 12. DETALLE DE PEDIDOS: Control de montos y costos al modificar pedidos
-- ----------------------------------------------------------------------------
DROP TRIGGER IF EXISTS `detalle_pedido_BEFORE_UPDATE`;
DELIMITER $$
CREATE TRIGGER `detalle_pedido_BEFORE_UPDATE` BEFORE UPDATE ON `detalle_pedido` FOR EACH ROW 
BEGIN
    DECLARE estado_actual VARCHAR(20);
    
    -- No permitir modificar pedidos finalizados o procesados
    SELECT estado_pedido INTO estado_actual FROM pedidos WHERE id_pedido = NEW.id_pedido;
    IF estado_actual IN ('Anulado', 'Pagado', 'Enviado') THEN
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = 'Seguridad: No se puede modificar un pedido que ya ha sido Anulado, Pagado o Enviado.';
    END IF;
    
    IF NEW.cantidad <= 0 THEN
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = 'Validación: La cantidad de pedido debe ser mayor a cero.';
    END IF;
END$$
DELIMITER ;

DROP TRIGGER IF EXISTS `detalle_pedido_AFTER_UPDATE`;
DELIMITER $$
CREATE TRIGGER `detalle_pedido_AFTER_UPDATE` AFTER UPDATE ON `detalle_pedido` FOR EACH ROW 
BEGIN
    -- Recalcular total del pedido
    UPDATE pedidos 
    SET total_pedido = total_pedido 
        - (OLD.cantidad * OLD.precioUnitario * (1 + OLD.porcentaje_iva))
        + (NEW.cantidad * NEW.precioUnitario * (1 + NEW.porcentaje_iva))
    WHERE id_pedido = NEW.id_pedido;
    
    -- Actualizar costo de compra de referencia en el catálogo
    UPDATE productos
    SET precioCompra = NEW.precioUnitario
    WHERE id_producto = NEW.id_producto;
END$$
DELIMITER ;
